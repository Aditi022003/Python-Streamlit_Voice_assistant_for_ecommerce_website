// script.js
const assistantResponse = document.getElementById('assistant-response');

function startListening() {
    const recognition = new webkitSpeechRecognition();
    recognition.lang = 'en-US';
    recognition.start();

    recognition.onresult = function(event) {
        const userSpeech = event.results[0][0].transcript.toLowerCase();
        assistantResponse.innerHTML = `<p>User said: ${userSpeech}</p>`;
        sendCommand(userSpeech);
    };
}

function sendCommand(command) {
    fetch('/command', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ command: command }),
    })
    .then(response => response.text())
    .then(data => {
        speak(data);
    })
    .catch((error) => {
        console.error('Error:', error);
    });
}

function speak(text) {
    const utterance = new SpeechSynthesisUtterance(text);
    speechSynthesis.speak(utterance);
}
